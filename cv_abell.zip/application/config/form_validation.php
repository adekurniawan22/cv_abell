<?php
$config['error_prefix'] = "<p style='font-size: 12px;color: red;' class='my-2'>";
$config['error_suffix'] = "</p>";
