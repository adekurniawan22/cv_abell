<?php
class Custom404 extends CI_Controller
{
    public function index()
    {
        echo "Halaman yang Anda cari tidak ditemukan.";
    }
}
